package com.dicoding.githubuser1

import android.content.Intent
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.lifecycle.ViewModelProvider
import androidx.viewpager2.widget.ViewPager2
import com.bumptech.glide.Glide
import com.dicoding.githubuser1.databinding.ActivityDetailBinding
import com.dicoding.githubuser1.repository.FavoriteRepository
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator


class DetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDetailBinding
    private lateinit var viewPager: ViewPager2
    private lateinit var tabLayout: TabLayout
    private lateinit var viewModel: DetailViewModel
    private lateinit var favoriteViewModel: FavoriteViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        viewPager = binding.viewPager2
        tabLayout = binding.tabLayout

        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Detail Github User"

        val username = intent.getStringExtra("username")

        viewModel = ViewModelProvider(this, DetailViewModelFactory(FavoriteRepository(application)))[DetailViewModel::class.java]
        favoriteViewModel = ViewModelProvider(this, FavoriteViewModelFactory(FavoriteRepository(application)))[FavoriteViewModel::class.java]

        showLoading(true)

        username?.let {
            viewModel.loadUserData(it)
            showLoading(true)
        }

        viewModel.userData.observe(this) { user ->

            if (user != null) {
                showLoading(false)
                val usernameTextView = binding.textUsername
                val nameTextView = binding.textName
                val followersTextView = binding.textFollowers
                val followingTextView = binding.textFollowing
                val avatarImageView = binding.imageAvatar
                val favoriteButton = binding.favoriteButton

                // Periksa status favorit berdasarkan data dari ViewModel
                val userIsFavorite = viewModel.isFavorite.value ?: false

                // Pengecekan null sebelum mengakses properti user
                if (user.login != null) {
                    usernameTextView.text = user.login
                } else {
                    usernameTextView.text = "Username tidak tersedia"
                }

                usernameTextView.text = user.login
                nameTextView.text = user.name
                followersTextView.text = "${user.followers} Followers"
                followingTextView.text = "${user.following} Following"


                Glide.with(this)
                    .load(user.avatarUrl)
                    .placeholder(R.drawable.placeholder_image)
                    .into(avatarImageView)




                // Atur ikon tombol favorit berdasarkan status favorit
                if (userIsFavorite) {
                    favoriteButton.setImageResource(R.drawable.ic_favorite)
                } else {
                    favoriteButton.setImageResource(R.drawable.baseline_favorite_border_24)
                }

                // Atur aksi klik pada tombol favorit
                favoriteButton.setOnClickListener {

                    val isCurrentlyFavorite = viewModel.isFavorite.value ?: false
                    viewModel.toggleFavoriteStatus(user.login, user.avatarUrl)

                    if (isCurrentlyFavorite) {
                        username?.let {
                            deleteFavorite(it, avatarUrl = null)
                        }
                    } else {
                        showToast("Ditandai sebagai favorit")
                        favoriteButton.setImageResource(R.drawable.ic_favorite)
                    }
                }
            } else {
                showLoading(false)
                showToast("Gagal mengambil data pengguna")
            }
        }
        val sectionsPagerAdapter = SectionsPagerAdapter(this)
        sectionsPagerAdapter.username = username

        viewPager.adapter = sectionsPagerAdapter

        TabLayoutMediator(tabLayout, viewPager) { tab, position ->
            tab.text = if (position == 0) "Followers" else "Following"
        }.attach()

        viewModel.networkError.observe(this) { errorMessage ->
            if (!errorMessage.isNullOrBlank()) {
                showToast(errorMessage)
            }
        }

        val ivFavorite = findViewById<ImageView>(R.id.ivFavorite)
        ivFavorite.setOnClickListener {
            val intent = Intent(this, FavoriteActivity::class.java)
            startActivity(intent)
        }
        val ivShare = findViewById<ImageView>(R.id.ivShare)
        ivShare.setOnClickListener {
            shareProfile(username)
        }


        // Atur tema sesuai preferensi
        val pref = SettingPreferences.getInstance(application.dataStore)
        val settingViewModel = ViewModelProvider(this, ViewModelFactory(pref)).get(SettingViewModel::class.java)

        settingViewModel.getThemeSettings().observe(this) { isDarkModeActive: Boolean ->
            if (isDarkModeActive) {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
            } else {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
            }
        }

    }

    private fun deleteFavorite(username: String, avatarUrl: String?= null) {

        favoriteViewModel.removeFromFavorite(username, avatarUrl)

        // Tampilkan pesan atau notifikasi yang sesuai jika perlu
        showToast("Tidak lagi favorit")

        // Set gambar tombol favorit sesuai status
        binding.favoriteButton.setImageResource(R.drawable.baseline_favorite_border_24)
    }


    private fun showLoading(state: Boolean) {
        binding.progressBar.visibility = if (state) View.VISIBLE else View.GONE
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> {
                finish()
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    private fun shareProfile(username: String?) {
        val shareText = "Check out this GitHub user's profile: https://github.com/$username"
        val shareIntent = Intent(Intent.ACTION_SEND)
        shareIntent.type = "text/plain"
        shareIntent.putExtra(Intent.EXTRA_SUBJECT, "GitHub Profile")
        shareIntent.putExtra(Intent.EXTRA_TEXT, shareText)
        startActivity(Intent.createChooser(shareIntent, "Share Profile"))
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("viewPagerPosition", viewPager.currentItem)
    }

    override fun onRestoreInstanceState(savedInstanceState: Bundle) {
        super.onRestoreInstanceState(savedInstanceState)
        val position = savedInstanceState.getInt("viewPagerPosition")
        viewPager.setCurrentItem(position, false)
    }

}
