package com.dicoding.githubuser1

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ProgressBar
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.dicoding.githubuser1.data.response.FollowersResponseItem
import com.dicoding.githubuser1.data.response.FollowingResponseItem
import com.dicoding.githubuser1.databinding.FragmentFollowBinding

class FollowFragment : Fragment() {

    companion object {
        @JvmStatic
        val ARG_POSITION = "position"

        @JvmStatic
        val ARG_USERNAME = "username"
    }

    private lateinit var binding: FragmentFollowBinding
    private var position: Int = 0
    private var username: String = ""
    private lateinit var followersViewModel: FollowersViewModel
    private lateinit var followingViewModel: FollowingViewModel
    private lateinit var followersProgressBar: ProgressBar
    private lateinit var adapter: UserFollowAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentFollowBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val recyclerView: RecyclerView = binding.recyclerView2
        adapter = UserFollowAdapter(requireContext(), ArrayList())
        recyclerView.layoutManager = LinearLayoutManager(requireContext())
        recyclerView.adapter = adapter

        arguments?.let { arguments ->
            position = arguments.getInt(ARG_POSITION)
            username = arguments.getString(ARG_USERNAME) ?: ""
        }

        followersViewModel = ViewModelProvider(this)[FollowersViewModel::class.java]
        followingViewModel = ViewModelProvider(this)[FollowingViewModel::class.java]

        followersProgressBar = view.findViewById(R.id.followersProgressBar)

        followersProgressBar.visibility = View.VISIBLE

        if (position == 1) {
            val cachedFollowersData = followersViewModel.getListFollowers().value
            if (cachedFollowersData != null) {
                adapter.followerupdateData(cachedFollowersData)
                followersProgressBar.visibility = View.GONE
            } else {
                followersViewModel.loadFollowers(username)
            }
        } else if (position == 2) {
            val cachedFollowingData = followingViewModel.getListFollowing().value
            if (cachedFollowingData != null) {
                adapter.followingupdateData(cachedFollowingData)
                followersProgressBar.visibility = View.GONE
            } else {
                followingViewModel.loadFollowing(username)
            }
        }

        followersViewModel.errorMessage.observe(viewLifecycleOwner) { errorMessage ->
            if (!errorMessage.isNullOrEmpty()) {
                Toast.makeText(requireContext(), errorMessage, Toast.LENGTH_SHORT).show()
            }
        }
        followingViewModel.errorMessage.observe(viewLifecycleOwner) { errorMessage ->
            if (!errorMessage.isNullOrEmpty()) {
                Toast.makeText(requireContext(), errorMessage, Toast.LENGTH_SHORT).show()
            }
        }

        followersViewModel.getListFollowers().observe(viewLifecycleOwner) { followers: List<FollowersResponseItem>? ->
            adapter.followerupdateData(followers ?: emptyList())
            followersProgressBar.visibility = View.GONE
        }

        followingViewModel.getListFollowing().observe(viewLifecycleOwner) { following: List<FollowingResponseItem>? ->
            adapter.followingupdateData(following ?: emptyList())
            followersProgressBar.visibility = View.GONE
        }
    }
}