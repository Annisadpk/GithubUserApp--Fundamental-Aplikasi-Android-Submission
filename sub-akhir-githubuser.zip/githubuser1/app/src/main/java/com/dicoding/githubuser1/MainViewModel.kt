package com.dicoding.githubuser1
import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.dicoding.githubuser1.data.response.ItemsItem
import com.dicoding.githubuser1.data.retrofit.ApiConfig
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.IOException

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val _users = MutableLiveData<List<ItemsItem>>()
    val users: LiveData<List<ItemsItem>> = _users

    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading

    private val _networkError = MutableLiveData<String>()
    val networkError: LiveData<String> = _networkError

    fun setSearchQuery(query: String) {
        searchGitHubUsers(query)
    }

    fun searchGitHubUsers(query: String) {
        showProgressBar()

        CoroutineScope(Dispatchers.IO).launch {
            try {
                val searchResponse = ApiConfig.getApiService().getSearch(query).execute()
                if (searchResponse.isSuccessful) {
                    val users = searchResponse.body()?.items ?: emptyList()

                    withContext(Dispatchers.Main) {
                        _users.value = users
                        hideProgressBar()
                    }
                } else {
                    val errorMessage = "Terjadi kesalahan saat melakukan pencarian. Kode error: ${searchResponse.code()}"
                    withContext(Dispatchers.Main) {
                        _networkError.value = errorMessage
                        hideProgressBar()
                    }
                }
            } catch (e: IOException) {
                e.printStackTrace()
                val errorMessage = "Terjadi kesalahan jaringan: ${e.message}"
                withContext(Dispatchers.Main) {
                    _networkError.value = errorMessage
                    hideProgressBar()
                }
            }
        }
    }


    private fun showProgressBar() {
        _isLoading.value = true
    }

    private fun hideProgressBar() {
        _isLoading.value = false
    }
}
