package com.dicoding.githubuser1.repository

import android.app.Application
import androidx.lifecycle.LiveData
import com.dicoding.githubuser1.database.Favorite
import com.dicoding.githubuser1.database.FavoriteDao
import com.dicoding.githubuser1.database.FavoriteRoomDatabase
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class FavoriteRepository(application: Application) {
    private val mFavoriteDao: FavoriteDao
    private val executorService: ExecutorService = Executors.newSingleThreadExecutor()

    init {
        val db = FavoriteRoomDatabase.getInstance(application)
        mFavoriteDao = db.favoriteDao()
    }

    fun isFavorite(username: String): LiveData<Boolean> {
        return mFavoriteDao.isFavorite(username)
    }

    fun getAllFavorites(): LiveData<List<Favorite>> = mFavoriteDao.getAllFavorites()

    fun insert(favorite: Favorite) {
        try {
            executorService.execute {
                mFavoriteDao.insert(favorite)
            }
        } catch (e: Exception) {
            // Handle exceptions here, if any
        }
    }


    fun delete(favorite: Favorite) {
        try {
            executorService.execute {
                mFavoriteDao.delete(favorite)
            }
        } catch (e: Exception) {
            // Handle exceptions here, if any
        }
    }
}
