package com.dicoding.githubuser1.database

import android.os.Parcelable
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.parcelize.Parcelize

@Entity(tableName = "favorite_table")
@Parcelize
data class Favorite(
    @PrimaryKey (autoGenerate = false)
    @ColumnInfo(name = "username")
    val username: String,
    @ColumnInfo(name = "avatar")
    val avatarUrl: String?,
    @ColumnInfo(name = "is_favorite") // Add a column for isFavorite
    val isFavorite: Boolean
) : Parcelable
