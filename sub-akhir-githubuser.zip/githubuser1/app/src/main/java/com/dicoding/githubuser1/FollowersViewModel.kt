package com.dicoding.githubuser1

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.dicoding.githubuser1.data.response.FollowersResponseItem
import com.dicoding.githubuser1.data.retrofit.ApiConfig
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class FollowersViewModel : ViewModel() {
    val followersData = MutableLiveData<List<FollowersResponseItem>>()
    private val _errorMessage = MutableLiveData<String>()

    val errorMessage: LiveData<String>
        get() = _errorMessage //

    fun loadFollowers(username: String) {
        ApiConfig.getApiService().getfollowers(username)
            .enqueue(object : Callback<List<FollowersResponseItem>> {
                override fun onFailure(call: Call<List<FollowersResponseItem>>, t: Throwable) {
                    val errorMessageText = t.message ?: "Terjadi kesalahan tidak diketahui"
                    _errorMessage.postValue(errorMessageText)
                }

                override fun onResponse(
                    call: Call<List<FollowersResponseItem>>,
                    response: Response<List<FollowersResponseItem>>
                ) {
                    if (response.isSuccessful) {
                        followersData.postValue(response.body())
                    } else {
                        val errorMessageText = "Terjadi kesalahan: ${response.code()}"
                        _errorMessage.postValue(errorMessageText)
                    }
                }
            })
    }

    fun getListFollowers(): LiveData<List<FollowersResponseItem>> {
        return followersData
    }
}
