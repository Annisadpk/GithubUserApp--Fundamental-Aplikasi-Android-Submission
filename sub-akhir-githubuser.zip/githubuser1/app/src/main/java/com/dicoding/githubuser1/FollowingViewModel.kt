package com.dicoding.githubuser1

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.dicoding.githubuser1.data.response.FollowingResponseItem
import com.dicoding.githubuser1.data.retrofit.ApiConfig
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class FollowingViewModel : ViewModel() {
    private val followingData = MutableLiveData<List<FollowingResponseItem>>()
    private val _errorMessage = MutableLiveData<String>()

    val errorMessage: LiveData<String>
        get() = _errorMessage

    fun loadFollowing(username: String) {
        ApiConfig.getApiService().getfollowing(username)
            .enqueue(object : Callback<List<FollowingResponseItem>> {
                override fun onFailure(call: Call<List<FollowingResponseItem>>, t: Throwable) {
                    val errorMessageText = t.message ?: "Terjadi kesalahan tidak diketahui"
                    _errorMessage.postValue(errorMessageText)
                }

                override fun onResponse(
                    call: Call<List<FollowingResponseItem>>,
                    response: Response<List<FollowingResponseItem>>
                ) {
                    if (response.isSuccessful) {
                        followingData.postValue(response.body())
                    }else {
                        val errorMessageText = "Terjadi kesalahan: ${response.code()}"
                        _errorMessage.postValue(errorMessageText)
                    }
                }
            })
    }
    fun getListFollowing(): LiveData<List<FollowingResponseItem>> {
        return followingData
    }
}