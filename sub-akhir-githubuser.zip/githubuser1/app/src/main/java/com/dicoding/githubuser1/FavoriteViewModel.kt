package com.dicoding.githubuser1

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.dicoding.githubuser1.database.Favorite
import com.dicoding.githubuser1.repository.FavoriteRepository

class FavoriteViewModel(private val favoriteRepository: FavoriteRepository) : ViewModel() {
    val allFavorites: LiveData<List<Favorite>> = favoriteRepository.getAllFavorites()
    // Di dalam FavoriteViewModel

    fun addToFavorite(username: String, avatarUrl: String?) {
        val favorite = Favorite(username, avatarUrl, true)
        favoriteRepository.insert(favorite)
    }

    fun removeFromFavorite(username: String, avatarUrl: String?) {
        val favorite = Favorite(username, avatarUrl, false)
        favoriteRepository.delete(favorite)
    }
}
