package com.dicoding.githubuser1.data.retrofit

import com.dicoding.githubuser1.data.response.DetailUserResponse
import com.dicoding.githubuser1.data.response.FollowersResponseItem
import com.dicoding.githubuser1.data.response.FollowingResponseItem
import com.dicoding.githubuser1.data.response.UserResponse
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Headers
import retrofit2.http.Path
import retrofit2.http.Query

interface ApiService {
    @GET("/search/users")
    @Headers("Authorization: token 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")
    fun getSearch(
        @Query("q") query: String
    ): Call<UserResponse>

    @GET("users/{username}")
    @Headers("Authorization: token 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")
    fun getDetailUser(@Path("username") username: String): Call<DetailUserResponse>

    @GET("users/{username}/followers")
    @Headers("Authorization: token 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")
    fun getfollowers(@Path("username") username: String): Call<List<FollowersResponseItem>>

    @GET("users/{username}/following")
    @Headers("Authorization: token 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")
    fun getfollowing(@Path("username") username: String): Call<List<FollowingResponseItem>>
}
