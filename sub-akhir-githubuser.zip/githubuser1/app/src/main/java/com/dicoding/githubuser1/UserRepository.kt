package com.dicoding.githubuser1

import com.dicoding.githubuser1.data.response.DetailUserResponse
import com.dicoding.githubuser1.data.retrofit.ApiService
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class UserRepository {
    private val githubApi: ApiService

    init {
        val retrofit = Retrofit.Builder()
            .baseUrl("https://api.github.com/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()

        githubApi = retrofit.create(ApiService::class.java)
    }

    fun getUserByUsername(username: String, callback: (DetailUserResponse?) -> Unit) {
        val call = githubApi.getDetailUser(username)

        call.enqueue(object : Callback<DetailUserResponse> {
            override fun onResponse(call: Call<DetailUserResponse>, response: Response<DetailUserResponse>) {
                if (response.isSuccessful) {
                    val user = response.body()
                    callback(user)
                } else {
                    callback(null)
                }
            }

            override fun onFailure(call: Call<DetailUserResponse>, t: Throwable) {
                callback(null)
            }
        })
    }
}
