package com.dicoding.githubuser1

import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.dicoding.githubuser1.data.response.ItemsItem
import com.dicoding.githubuser1.databinding.ItemUserBinding

class UserAdapter(private var users: List<ItemsItem>) : RecyclerView.Adapter<UserAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemUserBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val user = users[position]
        holder.bind(user)
    }

    override fun getItemCount(): Int {
        return users.size
    }

    inner class ViewHolder(private val binding: ItemUserBinding) : RecyclerView.ViewHolder(binding.root) {

        fun bind(user: ItemsItem) {
            binding.textUsername.text = user.login
            Glide.with(binding.root)
                .load(user.avatarUrl)
                .placeholder(R.drawable.placeholder_image)
                .into(binding.imageProfile)

            binding.idTextView.text = "ID: ${user.id}"
            binding.nodeTextView.text = user.score.toString()

            itemView.setOnClickListener {
                val intent = Intent(itemView.context, DetailActivity::class.java)
                intent.putExtra("username", user.login)
                itemView.context.startActivity(intent)
            }
        }
    }

    fun updateData(newUsers: List<ItemsItem>) {
        users = newUsers
        notifyDataSetChanged()
    }


}
