package com.dicoding.githubuser1

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.dicoding.githubuser1.data.response.FollowersResponseItem
import com.dicoding.githubuser1.data.response.FollowingResponseItem
import com.dicoding.githubuser1.databinding.ItemFollowBinding
import com.dicoding.githubuser1.databinding.ItemFollowingBinding

class UserFollowAdapter(
    private val context: Context, // Tambahkan properti context
    private val userList: MutableList<Any>
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        return when (viewType) {
            TYPE_FOLLOWERS -> {
                val binding = ItemFollowBinding.inflate(inflater, parent, false)
                FollowersViewHolder(binding)
            }

            TYPE_FOLLOWING -> {
                val binding = ItemFollowingBinding.inflate(inflater, parent, false)
                FollowingViewHolder(binding)
            }

            else -> throw IllegalArgumentException("Invalid view type")
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val user = userList[position]
        when (holder) {
            is FollowersViewHolder -> holder.bind(user as FollowersResponseItem)
            is FollowingViewHolder -> holder.bind(user as FollowingResponseItem)
        }
    }

    override fun getItemCount(): Int {
        return userList.size
    }

    override fun getItemViewType(position: Int): Int {
        return when (userList[position]) {
            is FollowersResponseItem -> TYPE_FOLLOWERS
            is FollowingResponseItem -> TYPE_FOLLOWING
            else -> super.getItemViewType(position)
        }
    }

    inner class FollowersViewHolder(private val binding: ItemFollowBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(user: FollowersResponseItem) {
            binding.fousernameTextView.text = context.getString(R.string.user_login_placeholder, user.login)
            Glide.with(binding.root)
                .load(user.avatarUrl)
                .placeholder(R.drawable.placeholder_image)
                .into(binding.foavatarImageView)
            itemView.setOnClickListener {
                val intent = Intent(itemView.context, DetailActivity::class.java)
                intent.putExtra("username", user.login)
                itemView.context.startActivity(intent)
            }
        }
    }

    inner class FollowingViewHolder(private val binding: ItemFollowingBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(user: FollowingResponseItem) {
            binding.folusernameTextView.text = context.getString(R.string.user_login_placeholder, user.login)
            Glide.with(binding.root)
                .load(user.avatarUrl)
                .placeholder(R.drawable.placeholder_image)
                .into(binding.folavatarImageView)

            itemView.setOnClickListener {
                val intent = Intent(itemView.context, DetailActivity::class.java)
                intent.putExtra("username", user.login)
                itemView.context.startActivity(intent)
            }
        }
    }

    fun followerupdateData(newList: List<FollowersResponseItem>) {
        val oldSize = userList.size
        userList.clear()
        userList.addAll(newList)
        val newSize = userList.size

        if (newSize != oldSize) {
            notifyDataSetChanged()

        }
    }


    fun followingupdateData(newList: List<FollowingResponseItem>) {
        val oldSize = userList.size
        userList.clear()
        userList.addAll(newList)
        val newSize = userList.size

        if (newSize != oldSize) {
            notifyDataSetChanged()

        }
    }

    companion object {
        const val TYPE_FOLLOWERS = 0
        const val TYPE_FOLLOWING = 1
    }
}
