
package com.dicoding.githubuser1

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.appcompat.widget.SearchView
import androidx.appcompat.widget.Toolbar
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.dicoding.githubuser1.data.response.ItemsItem
import com.dicoding.githubuser1.databinding.ActivityMainBinding


class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var userAdapter: UserAdapter

    companion object {
        private const val USERNAME = "username"
        private const val SEARCH_QUERY_KEY = "q"
    }

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val toolbar = findViewById<Toolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)

        supportActionBar?.setDisplayHomeAsUpEnabled(false)

        val layoutManager = LinearLayoutManager(this)
        binding.recyclerView.layoutManager = layoutManager
        val itemDecoration = DividerItemDecoration(this, layoutManager.orientation)
        binding.recyclerView.addItemDecoration(itemDecoration)

        userAdapter = UserAdapter(emptyList<ItemsItem>())
        binding.recyclerView.adapter = userAdapter
        binding.searchView.queryHint = "Cari Pengguna lain"

        setupSearchView()

        viewModel.users.observe(this) { users ->
            displayUsers(users)
        }

        viewModel.isLoading.observe(this) { isLoading ->
            showLoading(isLoading)
        }


        if (savedInstanceState != null) {
            val savedQuery = savedInstanceState.getString(SEARCH_QUERY_KEY, "")
            binding.searchView.setQuery(savedQuery, false)
        } else {
            viewModel.setSearchQuery(USERNAME)
        }
        viewModel.networkError.observe(this) { errorMessage ->
            if (!errorMessage.isNullOrBlank()) {
                showToast(errorMessage)
            }
        }

        val ivFavorite = findViewById<ImageView>(R.id.ivFavorite)
        ivFavorite.setOnClickListener {
            val intent = Intent(this, FavoriteActivity::class.java)
            startActivity(intent)
        }

        val ivSettings = findViewById<ImageView>(R.id.ivSettings)
        ivSettings.setOnClickListener {
            val intent = Intent(this, SettingActivity::class.java)
            startActivity(intent)
        }

        // Atur tema sesuai preferensi
        val pref = SettingPreferences.getInstance(application.dataStore)
        val settingViewModel = ViewModelProvider(this, ViewModelFactory(pref)).get(SettingViewModel::class.java)

        settingViewModel.getThemeSettings().observe(this) { isDarkModeActive: Boolean ->
            if (isDarkModeActive) {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
            } else {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
            }
        }
    }

    private fun setupSearchView() {
        binding.searchView.isIconified = true
        binding.searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                if (!query.isNullOrBlank()) {
                    viewModel.searchGitHubUsers(query)
                    hideSearchViewKeyboard(binding.searchView)
                    userAdapter.updateData(emptyList())
                    binding.searchView.clearFocus()
                    return true
                }
                return false
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                return false
            }
        })
    }

    private fun displayUsers(users: List<ItemsItem>) {
        userAdapter.updateData(users)
    }

    private fun showLoading(isLoading: Boolean) {
        binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
    }

    private fun hideSearchViewKeyboard(searchView: SearchView) {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(searchView.windowToken, 0)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        val currentQuery = binding.searchView.query.toString()
        outState.putString(SEARCH_QUERY_KEY, currentQuery)
    }
    private fun showToast(message: String) {
            Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }


}
