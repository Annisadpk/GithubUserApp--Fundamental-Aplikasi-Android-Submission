package com.dicoding.githubuser1

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.dicoding.githubuser1.data.response.DetailUserResponse
import com.dicoding.githubuser1.database.Favorite
import com.dicoding.githubuser1.repository.FavoriteRepository
import java.io.IOException

class DetailViewModel(private val favoriteRepository: FavoriteRepository) : ViewModel() {

    private val _userData = MutableLiveData<DetailUserResponse>()
    val userData: LiveData<DetailUserResponse> get() = _userData

    private val _isFavorite = MutableLiveData<Boolean>()
    val isFavorite: LiveData<Boolean> get() = _isFavorite

    private val _networkError = MutableLiveData<String>()
    val networkError: LiveData<String> = _networkError

    fun loadUserData(username: String) {
        fetchDataFromRepository(username)
    }

    private fun fetchDataFromRepository(username: String) {
        val repository = UserRepository()

        try {
            repository.getUserByUsername(username) { user ->
                _userData.postValue(user)
            }
        } catch (e: IOException) {
            e.printStackTrace()
            val errorMessage = "Terjadi kesalahan jaringan: ${e.message}"
            _networkError.postValue(errorMessage)
        }

        // Menggunakan favoriteRepository.isFavorite(username).observe untuk mengamati LiveData
        favoriteRepository.isFavorite(username).observeForever { isCurrentlyFavorite ->
            _isFavorite.postValue(isCurrentlyFavorite)
        }
    }

    fun toggleFavoriteStatus(username: String, avatarUrl: String?) {
        val isCurrentlyFavoriteLiveData = favoriteRepository.isFavorite(username)

        val isCurrentlyFavorite = isCurrentlyFavoriteLiveData.value ?: false
        val newFavoriteStatus = !isCurrentlyFavorite


        _isFavorite.postValue(newFavoriteStatus)
        if (newFavoriteStatus) {
            // Menambahkan ke favorit
            val favorite = Favorite(username, avatarUrl, true)
            favoriteRepository.insert(favorite)
        } else {

        }
    }


}
